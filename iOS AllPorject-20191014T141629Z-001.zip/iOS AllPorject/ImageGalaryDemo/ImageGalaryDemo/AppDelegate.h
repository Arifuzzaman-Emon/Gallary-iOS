//
//  AppDelegate.h
//  ImageGalaryDemo
//
//  Created by Ahmed Shaheed on 2/11/18.
//  Copyright © 2018 mcc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


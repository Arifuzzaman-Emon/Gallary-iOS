//
//  ViewController.h
//  ImageGalaryDemo
//
//  Created by Ahmed Shaheed on 2/11/18.
//  Copyright © 2018 mcc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UICollectionViewDataSource>
@property NSMutableArray *photoItem;

@end


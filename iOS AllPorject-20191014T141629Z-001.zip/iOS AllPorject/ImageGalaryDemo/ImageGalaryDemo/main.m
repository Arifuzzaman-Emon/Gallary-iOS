//
//  main.m
//  ImageGalaryDemo
//
//  Created by Ahmed Shaheed on 2/11/18.
//  Copyright © 2018 mcc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

//
//  ViewController.m
//  ImageGalaryDemo
//
//  Created by Ahmed Shaheed on 2/11/18.
//  Copyright © 2018 mcc. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _photoItem = [[NSMutableArray alloc]initWithObjects:@"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", @"catcat", nil];
}

//this method is overridden to set how many image will be in a cell
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _photoItem.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //this line is used for creating recycler image cell
    UICollectionViewCell *myCell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellidentifier" forIndexPath:indexPath];
    
    //this line is used for get the image cell tag
    UIImageView *cellImage = (UIImageView *) [myCell viewWithTag:1];
    
    //this line is used for add image to the image cell
    cellImage.image = [UIImage imageNamed:[_photoItem objectAtIndex:indexPath.row]];
    
    //return the cell with image
    return myCell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
